<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array("database", "form_validation", "session");
$autoload['helper'] = array("html", "url", "form", "date", "download");
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
