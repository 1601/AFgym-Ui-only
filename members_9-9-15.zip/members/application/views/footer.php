		<footer>
			Adrenaline Fitness Alpha ver 1.0 Copyright &copy; 2015<?php if(date('Y') != '2015'){echo "-" . date('Y');}?>. 
		</footer>
	</body>
</html>